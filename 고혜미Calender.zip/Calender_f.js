var now = new Date(); // 서버 시간 기준 현재 로컬 시간
//console.log(new Date());
var utc = now.getTime() + now.getTimezoneOffset() * 60 * 1000; // 서버 기준 시간을 utc 시간으로 변환
// console.log(new Date().getTime());
// console.log(new Date().getTimezoneOffset());
// .getTime(): 1970년 1월 1일 00:00:00 UTC와 주어진 날짜까지의 시간을 밀리초로 반환한다.
// .getTimezoneOffset(): GMT 시간과 현지 시간의 차이를 분으로 반환한다. 시간이 더 앞에 있으면 음수가 된다.
var KoreaTimeDiff = 9 * 60 * 60 * 1000; // 한국시간은 UTC 기준 +9 시간이다
var koreaNow = new Date(utc + KoreaTimeDiff); // 따라서 utc에 KoreaTimeDiff 을 더해주면 현재 한국시간이 된다

var thisMonth = new Date(
  koreaNow.getFullYear(),
  koreaNow.getMonth(),
  koreaNow.getDate()
);
// 달력에서 표기하는 날짜 객체
var currentYear = thisMonth.getFullYear(); // 달력에서 표기하는 연
var currentMonth = thisMonth.getMonth(); // 달력에서 표기하는 월
var currentDate = thisMonth.getDate(); // 달력에서 표기하는 일

var prevBtn = document.getElementsByClassName("prevBtn")[0];
//.getElementsByClassName 메서드는 요소를 배열로 반환하므로 [0]을 추가하여 배열의 첫번째 요소에 접근한다
var nextBtn = document.getElementsByClassName("nextBtn")[0];
var nowMonth = document.getElementsByClassName("currentMonth")[0];
var calendarTable = document
  .getElementsByClassName("calendar")[0]
  .getElementsByTagName("tbody")[0];

// 이전 달로 이동
prevBtn.addEventListener("click", function () {
  currentMonth--;
  if (currentMonth < 0) {
    currentYear--;
    currentMonth = 11;
  }
  updateCalendar();
});

// 다음 달로 이동
nextBtn.addEventListener("click", function () {
  currentMonth++;
  if (currentMonth > 11) {
    currentYear++;
    currentMonth = 0;
  }
  updateCalendar();
});

// 달력 업데이트
function updateCalendar() {
  calendarTable.innerHTML = "";

  //현재월의 첫번째 날짜
  var firstDay = new Date(currentYear, currentMonth, 1);
  //var startDay = new Date(currentYear, currentMonth, 0);
  //새로운 date객체를 만들때 날짜를 0으로 지정하면 지난달의 마지막 날짜를 가진 date객체가 반환됌
  //첫번째 날짜의 요일
  var startingDay = firstDay.getDay();
  //현재월의 총 날짜 수
  var totalDays = new Date(currentYear, currentMonth + 1, 0).getDate();

  //지금 무슨 달인지 표시
  nowMonth.textContent = currentYear + "년 " + (currentMonth + 1) + "월";

  //날짜 표시하기
  var dayCount = 1;
  var rowCount = Math.ceil((startingDay + totalDays) / 7); // 행 수 계산
  for (var row = 0; row < rowCount; row++) {
    var newRow = calendarTable.insertRow();

    for (var col = 0; col < 7; col++) {
      var newCell = newRow.insertCell();

      if ((row === 0 && col < startingDay) || dayCount > totalDays) {
        newCell.textContent = "";
      } else {
        newCell.textContent = dayCount;
        newCell.addEventListener("click", function () {
          var selectedDate = new Date(
            currentYear,
            currentMonth,
            this.textContent
          );
          var formattedDate = selectedDate.toLocaleDateString("ko-KR", {
            //.toLocaleDateString() : 현재 시간을 추출해서 날짜를 상세히 표시해줌
            year: "numeric", //numberic : 2020 , 2-digit : 20 ...
            month: "long",
            day: "numeric",
          });
          alert(formattedDate + " 입니다.");
        });
        if (col === 0) {
          newCell.classList.add("sun");
        } else if (col === 6) {
          newCell.classList.add("sat");
        }

        dayCount++;
      }
    }
  }
}
// 초기 실행
updateCalendar();
